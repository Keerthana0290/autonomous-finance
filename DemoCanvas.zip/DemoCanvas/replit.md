# Overview

This is a full-stack TypeScript application for Autonomous Strategic Finance, designed as a comprehensive financial dashboard for companies. The application provides real-time financial metrics tracking, scenario modeling, revenue forecasting, cash flow analysis, and investment readiness assessments. Built for hackathon demonstration, it features a modern React frontend with shadcn/ui components and an Express.js backend with PostgreSQL database integration.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The client is built using **React** with **TypeScript** and follows a modern component-based architecture:

- **UI Framework**: Built with shadcn/ui components providing a comprehensive design system with Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming and responsive design
- **State Management**: React Query (TanStack Query) for server state management with custom query client configuration
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite with custom configuration for development and production builds
- **Component Structure**: Organized into dashboard-specific components, reusable UI components, and utility hooks

The frontend features a responsive dashboard with:
- Financial metrics overview with trend analysis
- Interactive charts for revenue forecasting and cash flow
- Scenario modeling with multiple projection types
- Investment readiness scoring
- Presentation mode for demos

## Backend Architecture

The server is built with **Express.js** and follows a RESTful API design:

- **Framework**: Express.js with TypeScript for type safety
- **Data Layer**: Modular storage interface with in-memory implementation for demo purposes
- **API Structure**: RESTful endpoints organized by functional domains (metrics, scenarios, investment readiness)
- **Development**: Hot reload with Vite middleware integration for seamless development experience

The backend provides endpoints for:
- Financial metrics retrieval by company
- Scenario management and projections
- Investment readiness calculations
- Consolidated dashboard data

## Database Design

Uses **Drizzle ORM** with **PostgreSQL** for type-safe database operations:

- **Schema Definition**: Strongly-typed schema with Zod validation
- **Tables**: Users, financial metrics, scenarios, and investment readiness data
- **Data Types**: JSON fields for flexible projection data and recommendations storage
- **Migrations**: Drizzle Kit for schema management and migrations

Key entities:
- `users`: Basic user authentication
- `financial_metrics`: Monthly/periodic financial data (MRR, ARR, burn rate, etc.)
- `scenarios`: Scenario modeling with assumptions and projections
- `investment_readiness`: Scoring and recommendations for investment preparation

## Development Workflow

The application uses a monorepo structure with:
- **Shared Types**: Common TypeScript interfaces and schemas in `/shared`
- **Client**: React frontend in `/client` with Vite build system
- **Server**: Express backend in `/server` with development hot reload
- **Build Process**: Separate client and server builds with production deployment support

# External Dependencies

## Database & ORM
- **Neon Database**: PostgreSQL serverless database (@neondatabase/serverless)
- **Drizzle ORM**: Type-safe ORM with PostgreSQL dialect and Zod integration

## Frontend Libraries
- **React**: Core framework with hooks and context
- **shadcn/ui**: Complete UI component library built on Radix UI primitives
- **TanStack Query**: Server state management and data fetching
- **Recharts**: Chart library for data visualization
- **Tailwind CSS**: Utility-first CSS framework
- **Wouter**: Lightweight routing library

## Backend Libraries
- **Express.js**: Web application framework
- **tsx**: TypeScript execution for development
- **esbuild**: Fast bundling for production builds

## Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type system and compiler
- **Replit Integration**: Development environment plugins for hot reload and error handling

## UI Components
Comprehensive component library including:
- Data visualization (charts, progress bars, metrics cards)
- Navigation (sidebar, breadcrumbs, tabs)
- Interactive elements (buttons, forms, dialogs)
- Layout components (cards, grids, containers)
- Accessibility features (tooltips, screen reader support)