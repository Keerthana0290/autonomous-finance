import { sql } from "drizzle-orm";
import { pgTable, text, varchar, real, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const financialMetrics = pgTable("financial_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").notNull(),
  period: text("period").notNull(), // YYYY-MM format
  mrr: real("mrr").notNull(),
  arr: real("arr").notNull(),
  burnRate: real("burn_rate").notNull(),
  cashRunway: integer("cash_runway").notNull(), // in months
  revenue: real("revenue").notNull(),
  expenses: real("expenses").notNull(),
  cashFlow: real("cash_flow").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const scenarios = pgTable("scenarios", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(), // optimistic, realistic, conservative
  assumptions: jsonb("assumptions").notNull(),
  projections: jsonb("projections").notNull(),
  probability: real("probability").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const investmentReadiness = pgTable("investment_readiness", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").notNull(),
  overallScore: real("overall_score").notNull(),
  revenueGrowthScore: real("revenue_growth_score").notNull(),
  marketSizeScore: real("market_size_score").notNull(),
  financialHealthScore: real("financial_health_score").notNull(),
  teamExecutionScore: real("team_execution_score").notNull(),
  recommendations: jsonb("recommendations").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").notNull(),
  role: text("role").notNull(), // 'user' or 'assistant'
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertFinancialMetricsSchema = createInsertSchema(financialMetrics).omit({
  id: true,
  createdAt: true,
});

export const insertScenarioSchema = createInsertSchema(scenarios).omit({
  id: true,
  createdAt: true,
});

export const insertInvestmentReadinessSchema = createInsertSchema(investmentReadiness).omit({
  id: true,
  updatedAt: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type FinancialMetrics = typeof financialMetrics.$inferSelect;
export type InsertFinancialMetrics = z.infer<typeof insertFinancialMetricsSchema>;
export type Scenario = typeof scenarios.$inferSelect;
export type InsertScenario = z.infer<typeof insertScenarioSchema>;
export type InvestmentReadiness = typeof investmentReadiness.$inferSelect;
export type InsertInvestmentReadiness = z.infer<typeof insertInvestmentReadinessSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
