import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateFinancialChatResponse } from "./openai";
import { insertChatMessageSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Financial metrics endpoints
  app.get("/api/metrics/:companyId", async (req, res) => {
    try {
      const { companyId } = req.params;
      const metrics = await storage.getFinancialMetrics(companyId);
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch financial metrics" });
    }
  });

  // Scenarios endpoints
  app.get("/api/scenarios/:companyId", async (req, res) => {
    try {
      const { companyId } = req.params;
      const scenarios = await storage.getScenarios(companyId);
      res.json(scenarios);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch scenarios" });
    }
  });

  // Investment readiness endpoints
  app.get("/api/investment-readiness/:companyId", async (req, res) => {
    try {
      const { companyId } = req.params;
      const readiness = await storage.getInvestmentReadiness(companyId);
      if (!readiness) {
        return res.status(404).json({ message: "Investment readiness data not found" });
      }
      res.json(readiness);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch investment readiness" });
    }
  });

  // Dashboard summary endpoint
  app.get("/api/dashboard/:companyId", async (req, res) => {
    try {
      const { companyId } = req.params;
      const [metrics, scenarios, investmentReadiness] = await Promise.all([
        storage.getFinancialMetrics(companyId),
        storage.getScenarios(companyId),
        storage.getInvestmentReadiness(companyId)
      ]);

      const latestMetrics = metrics[metrics.length - 1];
      
      res.json({
        currentMetrics: latestMetrics,
        historicalMetrics: metrics,
        scenarios,
        investmentReadiness
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard data" });
    }
  });

  // Chat endpoints
  app.get("/api/chat/:companyId", async (req, res) => {
    try {
      const { companyId } = req.params;
      const messages = await storage.getChatMessages(companyId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat messages" });
    }
  });

  app.post("/api/chat/message", async (req, res) => {
    try {
      const messageData = insertChatMessageSchema.parse(req.body);
      const message = await storage.createChatMessage(messageData);
      res.json(message);
    } catch (error) {
      res.status(500).json({ message: "Failed to save chat message" });
    }
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const { message, companyId } = req.body;
      
      if (!message || !companyId) {
        return res.status(400).json({ message: "Message and companyId are required" });
      }

      const response = await generateFinancialChatResponse({ message, companyId });
      res.json(response);
    } catch (error) {
      console.error("Chat API error:", error);
      res.status(500).json({ message: "Failed to generate AI response" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
