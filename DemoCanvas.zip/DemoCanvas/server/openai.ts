import OpenAI from "openai";
import { storage } from "./storage";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
let openai: OpenAI | null = null;

// Initialize OpenAI client lazily and safely
function getOpenAIClient(): OpenAI | null {
  if (openai === null && process.env.OPENAI_API_KEY) {
    try {
      openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    } catch (error) {
      console.error("Failed to initialize OpenAI client:", error);
      return null;
    }
  }
  return openai;
}

export interface ChatRequest {
  message: string;
  companyId: string;
}

export interface ChatResponse {
  message: string;
}

export async function generateFinancialChatResponse(request: ChatRequest): Promise<ChatResponse> {
  // Check if OpenAI client can be initialized
  const client = getOpenAIClient();
  if (!client) {
    return { 
      message: "I apologize, but I'm currently unable to process your request. The AI service is not available because the OpenAI API key is not configured. Please contact your administrator to set up the OPENAI_API_KEY environment variable." 
    };
  }

  try {
    // Get financial context for the company
    const [metrics, scenarios, investmentReadiness, chatHistory] = await Promise.all([
      storage.getFinancialMetrics(request.companyId),
      storage.getScenarios(request.companyId),
      storage.getInvestmentReadiness(request.companyId),
      storage.getChatMessages(request.companyId)
    ]);

    const latestMetrics = metrics[metrics.length - 1];
    
    // Build financial context for the AI
    const financialContext = `
Current Financial Data (Latest Period):
- Monthly Recurring Revenue (MRR): $${latestMetrics?.mrr?.toLocaleString() || 'N/A'}
- Annual Recurring Revenue (ARR): $${latestMetrics?.arr?.toLocaleString() || 'N/A'} 
- Monthly Burn Rate: $${latestMetrics?.burnRate?.toLocaleString() || 'N/A'}
- Cash Runway: ${latestMetrics?.cashRunway || 'N/A'} months
- Monthly Revenue: $${latestMetrics?.revenue?.toLocaleString() || 'N/A'}
- Monthly Expenses: $${latestMetrics?.expenses?.toLocaleString() || 'N/A'}
- Cash Flow: $${latestMetrics?.cashFlow?.toLocaleString() || 'N/A'}

Growth Scenarios:
${scenarios.map(scenario => `
- ${scenario.name} (${Math.round(scenario.probability * 100)}% probability):
  Growth Rate: ${Math.round((scenario.assumptions as any).growthRate * 100)}%
  Customer Acquisition: ${(scenario.assumptions as any).customerAcquisition}/month
  Churn Rate: ${Math.round((scenario.assumptions as any).churnRate * 100)}%
`).join('')}

Investment Readiness Score: ${investmentReadiness?.overallScore || 'N/A'}/10
${investmentReadiness?.recommendations ? 'Key Recommendations:\n' + (investmentReadiness.recommendations as string[]).map((rec: string) => `- ${rec}`).join('\n') : ''}

Historical Performance:
${metrics.slice(-6).map(m => `${m.period}: Revenue $${m.revenue?.toLocaleString()}, Cash Flow $${m.cashFlow?.toLocaleString()}`).join('\n')}
`;

    const systemPrompt = `You are a financial AI assistant specialized in helping startup founders and business owners analyze their financial data. You have access to real-time financial metrics, growth scenarios, and investment readiness data.

Your role is to:
- Provide insightful analysis of financial trends and patterns
- Offer strategic recommendations based on the data
- Help interpret financial metrics and their implications
- Suggest actionable steps for improving financial performance
- Answer questions about growth scenarios and investment readiness

Be conversational, helpful, and provide specific insights based on the actual data provided. Always reference specific numbers and trends from the financial context when relevant.

Current Financial Context:
${financialContext}`;

    // Build conversation history
    const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
      { role: "system", content: systemPrompt }
    ];

    // Add recent chat history (last 10 messages for context)
    const recentHistory = chatHistory.slice(-10);
    recentHistory.forEach(msg => {
      messages.push({
        role: msg.role as "user" | "assistant",
        content: msg.content
      });
    });

    // Add the current user message
    messages.push({
      role: "user",
      content: request.message
    });

    const response = await client.chat.completions.create({
      model: "gpt-5",
      messages,
      max_tokens: 1000,
    });

    const aiResponse = response.choices[0].message.content || "I apologize, but I couldn't generate a response. Please try again.";

    return { message: aiResponse };
  } catch (error) {
    console.error('OpenAI API error:', error);
    
    // Return a helpful error message that doesn't expose internal details
    if (!process.env.OPENAI_API_KEY) {
      return { message: "I apologize, but I'm currently unable to process your request. The OpenAI API key is not configured. Please contact your administrator to set up the OPENAI_API_KEY environment variable." };
    }
    
    return { message: "I apologize, but I encountered an error while processing your request. Please try again in a moment." };
  }
}