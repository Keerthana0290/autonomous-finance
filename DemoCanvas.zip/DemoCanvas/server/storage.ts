import { type User, type InsertUser, type FinancialMetrics, type InsertFinancialMetrics, type Scenario, type InsertScenario, type InvestmentReadiness, type InsertInvestmentReadiness, type ChatMessage, type InsertChatMessage } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getFinancialMetrics(companyId: string): Promise<FinancialMetrics[]>;
  createFinancialMetrics(metrics: InsertFinancialMetrics): Promise<FinancialMetrics>;
  
  getScenarios(companyId: string): Promise<Scenario[]>;
  createScenario(scenario: InsertScenario): Promise<Scenario>;
  
  getInvestmentReadiness(companyId: string): Promise<InvestmentReadiness | undefined>;
  upsertInvestmentReadiness(readiness: InsertInvestmentReadiness): Promise<InvestmentReadiness>;
  
  getChatMessages(companyId: string): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private financialMetrics: Map<string, FinancialMetrics>;
  private scenarios: Map<string, Scenario>;
  private investmentReadiness: Map<string, InvestmentReadiness>;
  private chatMessages: Map<string, ChatMessage>;

  constructor() {
    this.users = new Map();
    this.financialMetrics = new Map();
    this.scenarios = new Map();
    this.investmentReadiness = new Map();
    this.chatMessages = new Map();
    
    // Initialize with sample data for demo
    this.initializeSampleData();
  }

  private initializeSampleData() {
    const sampleCompanyId = "demo-company-1";
    
    // Sample financial metrics for the last 12 months
    const months = ['2024-01', '2024-02', '2024-03', '2024-04', '2024-05', '2024-06', 
                   '2024-07', '2024-08', '2024-09', '2024-10', '2024-11', '2024-12'];
    
    months.forEach((month, index) => {
      const id = randomUUID();
      const metrics: FinancialMetrics = {
        id,
        companyId: sampleCompanyId,
        period: month,
        mrr: 680000 + (index * 15000),
        arr: (680000 + (index * 15000)) * 12,
        burnRate: 145000 + (index * 2000),
        cashRunway: 20 - Math.floor(index / 6),
        revenue: 680000 + (index * 15000),
        expenses: 535000 + (index * 12000),
        cashFlow: (680000 + (index * 15000)) - (535000 + (index * 12000)),
        createdAt: new Date(),
      };
      this.financialMetrics.set(id, metrics);
    });

    // Sample scenarios
    const scenarios = [
      {
        id: randomUUID(),
        companyId: sampleCompanyId,
        name: "Optimistic Growth",
        type: "optimistic",
        assumptions: {
          growthRate: 0.25,
          customerAcquisition: 150,
          churnRate: 0.02
        },
        projections: {
          q1: 2.5, q2: 2.8, q3: 3.2, q4: 3.6,
          q5: 4.1, q6: 4.7, q7: 5.4, q8: 6.2
        },
        probability: 0.30,
        createdAt: new Date(),
      },
      {
        id: randomUUID(),
        companyId: sampleCompanyId,
        name: "Realistic Growth",
        type: "realistic",
        assumptions: {
          growthRate: 0.15,
          customerAcquisition: 100,
          churnRate: 0.05
        },
        projections: {
          q1: 2.5, q2: 2.7, q3: 2.9, q4: 3.1,
          q5: 3.4, q6: 3.7, q7: 4.0, q8: 4.3
        },
        probability: 0.55,
        createdAt: new Date(),
      },
      {
        id: randomUUID(),
        companyId: sampleCompanyId,
        name: "Conservative Growth",
        type: "conservative",
        assumptions: {
          growthRate: 0.05,
          customerAcquisition: 50,
          churnRate: 0.08
        },
        projections: {
          q1: 2.5, q2: 2.6, q3: 2.7, q4: 2.8,
          q5: 2.9, q6: 3.0, q7: 3.1, q8: 3.2
        },
        probability: 0.15,
        createdAt: new Date(),
      }
    ];

    scenarios.forEach(scenario => {
      this.scenarios.set(scenario.id, scenario as Scenario);
    });

    // Sample investment readiness
    const readiness: InvestmentReadiness = {
      id: randomUUID(),
      companyId: sampleCompanyId,
      overallScore: 8.2,
      revenueGrowthScore: 8.5,
      marketSizeScore: 7.8,
      financialHealthScore: 9.2,
      teamExecutionScore: 6.5,
      recommendations: [
        "Strengthen executive team with experienced CFO",
        "Improve customer acquisition cost metrics",
        "Establish clearer path to profitability"
      ],
      updatedAt: new Date(),
    };
    this.investmentReadiness.set(readiness.id, readiness);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getFinancialMetrics(companyId: string): Promise<FinancialMetrics[]> {
    return Array.from(this.financialMetrics.values()).filter(
      (metrics) => metrics.companyId === companyId
    ).sort((a, b) => a.period.localeCompare(b.period));
  }

  async createFinancialMetrics(insertMetrics: InsertFinancialMetrics): Promise<FinancialMetrics> {
    const id = randomUUID();
    const metrics: FinancialMetrics = { 
      ...insertMetrics, 
      id, 
      createdAt: new Date() 
    };
    this.financialMetrics.set(id, metrics);
    return metrics;
  }

  async getScenarios(companyId: string): Promise<Scenario[]> {
    return Array.from(this.scenarios.values()).filter(
      (scenario) => scenario.companyId === companyId
    );
  }

  async createScenario(insertScenario: InsertScenario): Promise<Scenario> {
    const id = randomUUID();
    const scenario: Scenario = { 
      ...insertScenario, 
      id, 
      createdAt: new Date() 
    };
    this.scenarios.set(id, scenario);
    return scenario;
  }

  async getInvestmentReadiness(companyId: string): Promise<InvestmentReadiness | undefined> {
    return Array.from(this.investmentReadiness.values()).find(
      (readiness) => readiness.companyId === companyId
    );
  }

  async upsertInvestmentReadiness(insertReadiness: InsertInvestmentReadiness): Promise<InvestmentReadiness> {
    const existing = await this.getInvestmentReadiness(insertReadiness.companyId);
    
    if (existing) {
      const updated: InvestmentReadiness = { 
        ...existing, 
        ...insertReadiness, 
        updatedAt: new Date() 
      };
      this.investmentReadiness.set(existing.id, updated);
      return updated;
    } else {
      const id = randomUUID();
      const readiness: InvestmentReadiness = { 
        ...insertReadiness, 
        id, 
        updatedAt: new Date() 
      };
      this.investmentReadiness.set(id, readiness);
      return readiness;
    }
  }

  async getChatMessages(companyId: string): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values()).filter(
      (message) => message.companyId === companyId
    ).sort((a, b) => a.createdAt!.getTime() - b.createdAt!.getTime());
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const message: ChatMessage = { 
      ...insertMessage, 
      id, 
      createdAt: new Date() 
    };
    this.chatMessages.set(id, message);
    return message;
  }
}

export const storage = new MemStorage();
