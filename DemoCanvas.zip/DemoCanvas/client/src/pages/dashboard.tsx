import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/dashboard/header";
import { Sidebar } from "@/components/dashboard/sidebar";
import { MetricsOverview } from "@/components/dashboard/metrics-overview";
import { RevenueForecasting } from "@/components/dashboard/revenue-forecasting";
import { ScenarioModeling } from "@/components/dashboard/scenario-modeling";
import { CashFlow } from "@/components/dashboard/cash-flow";
import { InvestmentReadinessCard } from "@/components/dashboard/investment-readiness";
import { ExecutiveSummary } from "@/components/dashboard/executive-summary";
import { getMetricCards, getRevenueChartData, getCashFlowData, DashboardData } from "@/lib/dashboard-data";

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const companyId = "demo-company-1"; // In a real app, this would come from auth/context

  const { data: dashboardData, isLoading, error } = useQuery<DashboardData>({
    queryKey: ["/api/dashboard", companyId],
  });

  // Close sidebar when clicking outside on mobile
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (window.innerWidth <= 768 && sidebarOpen) {
        const sidebar = document.querySelector('[data-testid="sidebar"]');
        const toggle = document.querySelector('[data-testid="button-sidebar-toggle"]');
        
        if (sidebar && !sidebar.contains(event.target as Node) && 
            toggle && !toggle.contains(event.target as Node)) {
          setSidebarOpen(false);
        }
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, [sidebarOpen]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-destructive mb-2">Failed to load dashboard data</p>
          <p className="text-muted-foreground">{(error as Error).message}</p>
        </div>
      </div>
    );
  }

  if (!dashboardData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">No data available</p>
      </div>
    );
  }

  const { currentMetrics, historicalMetrics, scenarios, investmentReadiness } = dashboardData;
  const previousMetrics = historicalMetrics[historicalMetrics.length - 2];
  const metricCards = getMetricCards(currentMetrics, previousMetrics);
  const revenueData = getRevenueChartData(historicalMetrics);
  const cashFlowData = getCashFlowData(historicalMetrics);

  return (
    <div className="min-h-screen bg-background">
      <Header onToggleSidebar={() => setSidebarOpen(!sidebarOpen)} />
      
      <div className="flex">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        
        <main className="main-content flex-1 p-6 ml-0 md:ml-64 transition-all duration-300">
          <MetricsOverview metrics={metricCards} />
          <RevenueForecasting data={revenueData} />
          <ScenarioModeling scenarios={scenarios} />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <CashFlow data={cashFlowData} />
            <InvestmentReadinessCard data={investmentReadiness} />
          </div>
          
          <ExecutiveSummary 
            currentMetrics={currentMetrics} 
            investmentReadiness={investmentReadiness} 
          />
        </main>
      </div>
    </div>
  );
}
