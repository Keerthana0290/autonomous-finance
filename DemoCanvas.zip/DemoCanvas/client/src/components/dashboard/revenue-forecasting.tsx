import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { useState } from "react";

interface RevenueData {
  month: string;
  actual: number;
  forecast: number | null;
  period: string;
}

interface RevenueForecastingProps {
  data: RevenueData[];
}

export function RevenueForecasting({ data }: RevenueForecastingProps) {
  const [forecastPeriod, setForecastPeriod] = useState("12M");

  const formatValue = (value: number) => `$${value}K`;

  return (
    <section className="mb-8">
      <Card className="shadow-sm">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold">Revenue Forecasting & Trend Analysis</h3>
            <div className="flex items-center space-x-2">
              {["12M", "24M", "36M"].map((period) => (
                <Button
                  key={period}
                  variant={forecastPeriod === period ? "default" : "outline"}
                  size="sm"
                  onClick={() => setForecastPeriod(period)}
                  data-testid={`button-forecast-${period.toLowerCase()}`}
                >
                  {period} Forecast
                </Button>
              ))}
            </div>
          </div>
          
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="month" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                  tickFormatter={formatValue}
                />
                <Tooltip 
                  formatter={(value: number) => [formatValue(value), ""]}
                  labelStyle={{ color: "hsl(var(--foreground))" }}
                  contentStyle={{ 
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "6px"
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="actual"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--primary))", strokeWidth: 2, r: 4 }}
                  name="Actual Revenue"
                />
                <Line
                  type="monotone"
                  dataKey="forecast"
                  stroke="hsl(var(--secondary))"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={{ fill: "hsl(var(--secondary))", strokeWidth: 2, r: 4 }}
                  connectNulls={false}
                  name="Forecasted Revenue"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          
          <div className="mt-4 flex items-center space-x-6 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-primary rounded-full"></div>
              <span>Actual Revenue</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-secondary rounded-full"></div>
              <span>Forecasted Revenue</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-accent rounded-full"></div>
              <span>Trend Line</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
