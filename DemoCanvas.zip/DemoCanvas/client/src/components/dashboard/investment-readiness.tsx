import { Card, CardContent } from "@/components/ui/card";
import { InvestmentReadiness } from "@shared/schema";

interface InvestmentReadinessProps {
  data: InvestmentReadiness;
}

export function InvestmentReadinessCard({ data }: InvestmentReadinessProps) {
  const scoreFactors = [
    {
      label: "Revenue Growth",
      score: data.revenueGrowthScore,
      color: "secondary"
    },
    {
      label: "Market Size",
      score: data.marketSizeScore,
      color: "primary"
    },
    {
      label: "Financial Health",
      score: data.financialHealthScore,
      color: "accent"
    },
    {
      label: "Team & Execution",
      score: data.teamExecutionScore,
      color: "destructive"
    }
  ];

  const getColorClass = (color: string) => {
    switch (color) {
      case "secondary":
        return "bg-secondary text-secondary";
      case "primary":
        return "bg-primary text-primary";
      case "accent":
        return "bg-accent text-accent";
      case "destructive":
        return "bg-destructive text-destructive";
      default:
        return "bg-primary text-primary";
    }
  };

  return (
    <Card className="shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-semibold">Investment Readiness Score</h3>
          <div className="flex items-center space-x-2">
            <div className="text-3xl font-bold text-primary" data-testid="text-overall-score">
              {data.overallScore.toFixed(1)}
            </div>
            <div className="text-sm text-muted-foreground">/10</div>
          </div>
        </div>
        
        <div className="space-y-4">
          {scoreFactors.map((factor, index) => (
            <div key={factor.label} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-2 h-2 rounded-full ${getColorClass(factor.color).split(' ')[0]}`}></div>
                <span className="text-sm font-medium">{factor.label}</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-24 bg-muted rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${getColorClass(factor.color).split(' ')[0]}`}
                    style={{ width: `${(factor.score / 10) * 100}%` }}
                  ></div>
                </div>
                <span 
                  className={`text-sm font-medium ${getColorClass(factor.color).split(' ')[1]}`}
                  data-testid={`text-score-${factor.label.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {factor.score.toFixed(1)}
                </span>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 p-4 bg-accent/10 rounded-lg">
          <h4 className="font-semibold text-accent mb-2">Key Recommendations</h4>
          <ul className="text-sm space-y-1 text-muted-foreground">
            {(data.recommendations as string[]).map((recommendation, index) => (
              <li key={index} data-testid={`text-recommendation-${index}`}>
                • {recommendation}
              </li>
            ))}
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
