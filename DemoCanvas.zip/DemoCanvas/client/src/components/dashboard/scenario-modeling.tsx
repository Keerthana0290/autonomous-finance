import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { TrendingUp, Equal, TrendingDown, Settings } from "lucide-react";
import { Scenario } from "@shared/schema";
import { formatPercentage, formatCurrency } from "@/lib/dashboard-data";

interface ScenarioModelingProps {
  scenarios: Scenario[];
}

export function ScenarioModeling({ scenarios }: ScenarioModelingProps) {
  const scenarioColors = {
    optimistic: "hsl(var(--secondary))",
    realistic: "hsl(var(--primary))",
    conservative: "hsl(var(--destructive))"
  };

  const getScenarioIcon = (type: string) => {
    switch (type) {
      case "optimistic":
        return <TrendingUp className="h-5 w-5 text-secondary" />;
      case "realistic":
        return <Equal className="h-5 w-5 text-primary" />;
      case "conservative":
        return <TrendingDown className="h-5 w-5 text-destructive" />;
      default:
        return <Equal className="h-5 w-5" />;
    }
  };

  const getScenarioData = () => {
    const quarters = ["Q1", "Q2", "Q3", "Q4", "Q1+1", "Q2+1", "Q3+1", "Q4+1"];
    
    return quarters.map((quarter, index) => {
      const dataPoint: any = { quarter };
      scenarios.forEach(scenario => {
        const projections = scenario.projections as any;
        const key = `q${index + 1}`;
        dataPoint[scenario.type] = projections[key] || 0;
      });
      return dataPoint;
    });
  };

  const chartData = getScenarioData();

  return (
    <section className="mb-8">
      <Card className="shadow-sm">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold">Automated Scenario Modeling</h3>
            <Button variant="outline" data-testid="button-configure-scenarios">
              <Settings className="mr-2 h-4 w-4" />
              Configure Scenarios
            </Button>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            {scenarios.map((scenario) => {
              const assumptions = scenario.assumptions as any;
              const isRealistic = scenario.type === "realistic";
              
              return (
                <div
                  key={scenario.id}
                  className={`p-4 border rounded-lg ${
                    isRealistic ? "border-2 border-primary bg-primary/5" : "border-border"
                  }`}
                  data-testid={`card-scenario-${scenario.type}`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <h4 className={`font-semibold capitalize ${
                      scenario.type === "optimistic" ? "text-secondary" :
                      scenario.type === "realistic" ? "text-primary" :
                      "text-destructive"
                    }`}>
                      {scenario.name}
                    </h4>
                    {getScenarioIcon(scenario.type)}
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Growth Rate:</span>
                      <span className={`font-medium ${
                        scenario.type === "optimistic" ? "text-secondary" :
                        scenario.type === "realistic" ? "text-primary" :
                        "text-destructive"
                      }`}>
                        {formatPercentage(assumptions.growthRate)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Probability:</span>
                      <span className="font-medium">{formatPercentage(scenario.probability)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="quarter" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                  tickFormatter={(value) => `$${value}M`}
                />
                <Tooltip 
                  formatter={(value: number, name: string) => [`$${value}M`, name]}
                  labelStyle={{ color: "hsl(var(--foreground))" }}
                  contentStyle={{ 
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "6px"
                  }}
                />
                <Legend />
                {scenarios.map((scenario) => (
                  <Line
                    key={scenario.id}
                    type="monotone"
                    dataKey={scenario.type}
                    stroke={scenarioColors[scenario.type as keyof typeof scenarioColors]}
                    strokeWidth={2}
                    dot={{ strokeWidth: 2, r: 4 }}
                    name={scenario.name}
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
