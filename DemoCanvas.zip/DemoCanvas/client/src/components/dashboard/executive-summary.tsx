import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Share } from "lucide-react";
import { FinancialMetrics, InvestmentReadiness } from "@shared/schema";
import { formatCurrency } from "@/lib/dashboard-data";

interface ExecutiveSummaryProps {
  currentMetrics: FinancialMetrics;
  investmentReadiness: InvestmentReadiness;
}

export function ExecutiveSummary({ currentMetrics, investmentReadiness }: ExecutiveSummaryProps) {
  return (
    <section className="mb-8">
      <Card className="shadow-sm">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold">Executive Summary</h3>
            <div className="flex items-center space-x-2">
              <Button variant="default" data-testid="button-export-report">
                <FileText className="mr-2 h-4 w-4" />
                Export Report
              </Button>
              <Button variant="outline" data-testid="button-share">
                <Share className="mr-2 h-4 w-4" />
                Share
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-3">Financial Highlights</h4>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Current ARR:</span>
                  <span className="font-medium" data-testid="text-current-arr">
                    {formatCurrency(currentMetrics.arr, true)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Projected 12M ARR:</span>
                  <span className="font-medium" data-testid="text-projected-arr">
                    {formatCurrency(currentMetrics.arr * 1.15, true)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Monthly Growth Rate:</span>
                  <span className="font-medium text-secondary" data-testid="text-growth-rate">
                    12.5%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Cash Runway:</span>
                  <span className="font-medium" data-testid="text-cash-runway">
                    {currentMetrics.cashRunway} months
                  </span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-3">Investment Readiness</h4>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Overall Score:</span>
                  <span className="font-medium text-primary" data-testid="text-summary-score">
                    {investmentReadiness.overallScore.toFixed(1)}/10
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Funding Recommendation:</span>
                  <span className="font-medium text-secondary" data-testid="text-funding-recommendation">
                    Series A Ready
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Optimal Raise:</span>
                  <span className="font-medium" data-testid="text-optimal-raise">
                    $3.5M - $5M
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Time to Market:</span>
                  <span className="font-medium" data-testid="text-time-to-market">
                    Q2 2024
                  </span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
