import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useState } from "react";

interface CashFlowData {
  month: string;
  cashIn: number;
  cashOut: number;
}

interface CashFlowProps {
  data: CashFlowData[];
}

export function CashFlow({ data }: CashFlowProps) {
  const [viewType, setViewType] = useState("monthly");

  const formatValue = (value: number) => `$${Math.abs(value)}K`;

  const currentMonth = data[data.length - 1];

  return (
    <Card className="shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-semibold">Cash Flow Projection</h3>
          <div className="flex items-center space-x-2">
            {["monthly", "quarterly"].map((type) => (
              <Button
                key={type}
                variant={viewType === type ? "default" : "outline"}
                size="sm"
                onClick={() => setViewType(type)}
                data-testid={`button-cashflow-${type}`}
              >
                {type.charAt(0).toUpperCase() + type.slice(1)}
              </Button>
            ))}
          </div>
        </div>
        
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="month" 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickFormatter={formatValue}
              />
              <Tooltip 
                formatter={(value: number, name: string) => [formatValue(value), name]}
                labelStyle={{ color: "hsl(var(--foreground))" }}
                contentStyle={{ 
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "6px"
                }}
              />
              <Bar
                dataKey="cashIn"
                fill="hsl(var(--secondary))"
                radius={[4, 4, 0, 0]}
                name="Cash In"
              />
              <Bar
                dataKey="cashOut"
                fill="hsl(var(--destructive))"
                radius={[4, 4, 0, 0]}
                name="Cash Out"
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
        
        <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center justify-between p-3 bg-muted rounded-md">
            <span className="text-muted-foreground">Cash In:</span>
            <span className="font-semibold text-secondary" data-testid="text-cash-in">
              {formatValue(currentMonth?.cashIn || 0)}
            </span>
          </div>
          <div className="flex items-center justify-between p-3 bg-muted rounded-md">
            <span className="text-muted-foreground">Cash Out:</span>
            <span className="font-semibold text-destructive" data-testid="text-cash-out">
              {formatValue(currentMonth?.cashOut || 0)}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
