import { cn } from "@/lib/utils";
import { 
  BarChart3, 
  Calculator, 
  Coins, 
  Medal, 
  FileText, 
  Plus, 
  Download,
  Home,
  MessageSquare
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location] = useLocation();
  
  const navItems = [
    { icon: Home, label: "Dashboard", href: "/", path: "/" },
    { icon: MessageSquare, label: "AI Chat", href: "/chat", path: "/chat" },
    { icon: BarChart3, label: "Revenue Forecasting", href: "#", path: null },
    { icon: Calculator, label: "Scenario Modeling", href: "#", path: null },
    { icon: Coins, label: "Cash Flow", href: "#", path: null },
    { icon: Medal, label: "Investment Readiness", href: "#", path: null },
    { icon: FileText, label: "Reports", href: "#", path: null },
  ];

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={onClose}
          data-testid="sidebar-overlay"
        />
      )}
      
      <aside 
        className={cn(
          "sidebar w-64 bg-card border-r border-border h-screen sticky top-16 pt-6 transition-transform duration-300",
          "md:translate-x-0",
          isOpen ? "translate-x-0" : "-translate-x-full",
          "fixed md:static z-50 md:z-auto"
        )}
        data-testid="sidebar"
      >
        <nav className="px-4 space-y-2">
          {navItems.map((item) => {
            const isActive = item.path ? location === item.path : false;
            
            return item.path ? (
              <Link
                key={item.label}
                href={item.href}
                className={cn(
                  "flex items-center space-x-3 px-3 py-2 rounded-md transition-colors cursor-pointer",
                  isActive
                    ? "bg-primary text-primary-foreground"
                    : "hover:bg-muted text-muted-foreground hover:text-foreground"
                )}
                data-testid={`link-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => onClose()}
              >
                <item.icon className="h-5 w-5" />
                <span>{item.label}</span>
              </Link>
            ) : (
              <a
                key={item.label}
                href={item.href}
                className={cn(
                  "flex items-center space-x-3 px-3 py-2 rounded-md transition-colors",
                  "hover:bg-muted text-muted-foreground hover:text-foreground"
                )}
                data-testid={`link-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <item.icon className="h-5 w-5" />
                <span>{item.label}</span>
              </a>
            );
          })}
        </nav>
        
        <div className="px-4 mt-8">
          <div className="bg-muted rounded-lg p-4">
            <h3 className="font-semibold text-sm mb-2">Quick Actions</h3>
            <div className="space-y-2">
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-left"
                data-testid="button-new-forecast"
              >
                <Plus className="mr-2 h-4 w-4 text-primary" />
                New Forecast
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-left"
                data-testid="button-export-data"
              >
                <Download className="mr-2 h-4 w-4 text-secondary" />
                Export Data
              </Button>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
