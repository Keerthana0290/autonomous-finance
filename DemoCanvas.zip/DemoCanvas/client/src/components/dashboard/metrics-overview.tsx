import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, TrendingDown, BarChart3, Calendar, Clock, Flame } from "lucide-react";
import { MetricCardData } from "@/lib/dashboard-data";

interface MetricsOverviewProps {
  metrics: MetricCardData[];
}

export function MetricsOverview({ metrics }: MetricsOverviewProps) {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "chart-line":
        return <BarChart3 className="h-5 w-5 text-primary" />;
      case "calendar-alt":
        return <Calendar className="h-5 w-5 text-secondary" />;
      case "hourglass-half":
        return <Clock className="h-5 w-5 text-accent" />;
      case "fire":
        return <Flame className="h-5 w-5 text-destructive" />;
      default:
        return <BarChart3 className="h-5 w-5 text-primary" />;
    }
  };

  return (
    <section className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Financial Overview</h2>
        <div className="flex items-center space-x-2">
          <select 
            className="px-3 py-2 border border-border rounded-md bg-background"
            data-testid="select-time-range"
          >
            <option>Last 12 Months</option>
            <option>YTD</option>
            <option>Custom Range</option>
          </select>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {metrics.map((metric, index) => (
          <Card key={index} className="shadow-sm" data-testid={`card-metric-${index}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-medium text-muted-foreground">{metric.title}</h3>
                {getIcon(metric.icon)}
              </div>
              <p className="text-3xl font-bold" data-testid={`text-metric-value-${index}`}>
                {metric.value}
              </p>
              <div className="flex items-center mt-2">
                <span className={`text-sm font-medium flex items-center ${
                  metric.trend.isPositive ? 'metric-trend-up' : 'metric-trend-down'
                }`}>
                  {metric.trend.isPositive ? (
                    <TrendingUp className="mr-1 h-4 w-4" />
                  ) : (
                    <TrendingDown className="mr-1 h-4 w-4" />
                  )}
                  {metric.trend.value}
                </span>
                <span className="text-muted-foreground text-sm ml-2">{metric.trend.label}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}
