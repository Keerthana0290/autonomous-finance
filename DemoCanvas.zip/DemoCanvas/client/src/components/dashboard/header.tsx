import { Button } from "@/components/ui/button";
import { ChartPie, X, Menu } from "lucide-react";
import { usePresentationMode } from "@/hooks/use-presentation-mode";

interface HeaderProps {
  onToggleSidebar: () => void;
}

export function Header({ onToggleSidebar }: HeaderProps) {
  const { isPresentationMode, togglePresentationMode } = usePresentationMode();

  return (
    <header className="bg-card border-b border-border px-6 py-4 sticky top-0 z-40 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={onToggleSidebar}
            data-testid="button-sidebar-toggle"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-primary">
            <ChartPie className="inline mr-2 h-6 w-6" />
            Autonomous Strategic Finance
          </h1>
        </div>
        
        <div className="flex items-center space-x-4">
          <Button
            onClick={togglePresentationMode}
            className="bg-accent text-accent-foreground hover:bg-accent/90"
            data-testid="button-presentation-mode"
          >
            {isPresentationMode ? (
              <>
                <X className="mr-2 h-4 w-4" />
                Exit Presentation
              </>
            ) : (
              <>
                <ChartPie className="mr-2 h-4 w-4" />
                Presentation Mode
              </>
            )}
          </Button>
          
          <div className="relative">
            <Button variant="ghost" className="flex items-center space-x-2" data-testid="button-user-menu">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-sm font-medium">
                JD
              </div>
              <span className="hidden md:block font-medium">John Doe</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
