import { FinancialMetrics, Scenario, InvestmentReadiness } from "@shared/schema";

export interface DashboardData {
  currentMetrics: FinancialMetrics;
  historicalMetrics: FinancialMetrics[];
  scenarios: Scenario[];
  investmentReadiness: InvestmentReadiness;
}

export interface MetricCardData {
  title: string;
  value: string;
  trend: {
    value: string;
    isPositive: boolean;
    label: string;
  };
  icon: string;
}

export const formatCurrency = (value: number, compact = false): string => {
  if (compact && value >= 1000000) {
    return `$${(value / 1000000).toFixed(1)}M`;
  } else if (compact && value >= 1000) {
    return `$${(value / 1000).toFixed(0)}K`;
  }
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

export const formatNumber = (value: number): string => {
  return new Intl.NumberFormat('en-US').format(value);
};

export const formatPercentage = (value: number): string => {
  return `${(value * 100).toFixed(1)}%`;
};

export const getMetricCards = (current: FinancialMetrics, previous?: FinancialMetrics): MetricCardData[] => {
  const calculateTrend = (currentVal: number, previousVal?: number) => {
    if (!previousVal) return { value: "0%", isPositive: true, label: "vs last month" };
    
    const change = ((currentVal - previousVal) / previousVal) * 100;
    return {
      value: `${Math.abs(change).toFixed(1)}%`,
      isPositive: change >= 0,
      label: "vs last month"
    };
  };

  return [
    {
      title: "Monthly Recurring Revenue",
      value: formatCurrency(current.mrr, true),
      trend: calculateTrend(current.mrr, previous?.mrr),
      icon: "chart-line"
    },
    {
      title: "Annual Run Rate",
      value: formatCurrency(current.arr, true),
      trend: calculateTrend(current.arr, previous?.arr),
      icon: "calendar-alt"
    },
    {
      title: "Cash Runway",
      value: `${current.cashRunway} months`,
      trend: {
        value: previous ? `${Math.abs(current.cashRunway - previous.cashRunway)} months` : "0 months",
        isPositive: previous ? current.cashRunway >= previous.cashRunway : true,
        label: "vs last quarter"
      },
      icon: "hourglass-half"
    },
    {
      title: "Burn Rate",
      value: formatCurrency(current.burnRate, true),
      trend: calculateTrend(current.burnRate, previous?.burnRate),
      icon: "fire"
    }
  ];
};

export const getRevenueChartData = (metrics: FinancialMetrics[]) => {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  
  return metrics.map((metric, index) => ({
    month: months[index % 12],
    actual: metric.revenue / 1000, // Convert to thousands
    forecast: index >= 6 ? (metric.revenue * 1.15) / 1000 : null, // 15% growth forecast
    period: metric.period
  }));
};

export const getCashFlowData = (metrics: FinancialMetrics[]) => {
  return metrics.slice(-6).map((metric, index) => ({
    month: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"][index],
    cashIn: metric.revenue / 1000,
    cashOut: -metric.expenses / 1000
  }));
};
