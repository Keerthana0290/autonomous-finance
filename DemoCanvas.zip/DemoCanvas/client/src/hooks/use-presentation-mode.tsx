import { useState, useEffect } from "react";

export function usePresentationMode() {
  const [isPresentationMode, setIsPresentationMode] = useState(false);

  useEffect(() => {
    if (isPresentationMode) {
      document.body.classList.add('presentation-mode');
    } else {
      document.body.classList.remove('presentation-mode');
    }

    return () => {
      document.body.classList.remove('presentation-mode');
    };
  }, [isPresentationMode]);

  const togglePresentationMode = () => {
    setIsPresentationMode(!isPresentationMode);
  };

  return {
    isPresentationMode,
    togglePresentationMode
  };
}
